import { useState, useReducer, useCallback, useMemo } from "react";

function Calculator() {

    const [inputOne, setInputOne] = useState(null);
    const [inputTwo, setInputTwo] = useState(null);

    const reducer = (state, action) => {
        switch (action.type) {
        case "+":
            return { result: inputOne + inputTwo };
        case "-":
            return { result: inputOne - inputTwo };
        case "*":
            return { result: inputOne * inputTwo };
        case "/":
            return { result: inputTwo !== 0 ? inputOne / inputTwo : "Dividing by zero is not allowed"};
        default:
            throw new Error("Unknown action.");
        }
      };

    const [state, dispatch] = useReducer(reducer, {result: null});
    const handleAdd = useCallback(() => dispatch({ type: '+' }), []);
    const handleSub = useCallback(() => dispatch({ type: '-' }), []);
    const handleMul = useCallback(() => dispatch({ type: '*' }), []);
    const handleDiv = useCallback(() => dispatch({ type: '/' }), []);

    const result = useMemo(() => {
        return state.result;
    }, [state.result]);

    return (
        <div className="calculator-div">
            <div className="calculator-inputs">
                <label>Input 1
                    <input type="number" value={inputOne} onChange={(e) => setInputOne(parseFloat(e.target.value) || 0)}/>
                </label>
                <label>Input 2
                    <input type="number" value={inputTwo} onChange={(e) => setInputTwo(parseFloat(e.target.value) || 0)}/>
                </label>
                <label>Answer
                    <input readOnly value={result}/>
                </label>
            </div>
            <div className="calculator-operations">
                <button onClick={handleAdd}>Addition</button>
                <button onClick={handleSub}>Subtraction</button>
                <button onClick={handleMul}>Multiplication</button>
                <button onClick={handleDiv}>Division</button>
            </div>
        </div>
    )
}

export default Calculator;