import { useState, useEffect, useRef, useCallback } from "react";

function LoginForm({ onLogin, userInfo }) {
    const usernameRef = useRef('');
    const passwordRef = useRef('');
    const useDebounce = (callback, delay) => {
        const [debouncing, setDebouncing] = useState(false);

        useEffect(() => {
            if (!debouncing) return;

            const handler = setTimeout(() => {
                callback();
                setDebouncing(false);
            }, delay);

        return () => clearTimeout(handler);
        }, [debouncing, callback, delay]);

        return () => setDebouncing(true);
    };

    const [isLoggingIn, setIsLoggingIn] = useState(false);

    const debouncedLogin = useDebounce(() => {
        if (usernameRef.current === userInfo.username && passwordRef.current === userInfo.password) {
            onLogin();
        } else {
            alert('Invalid username or password.');
        }
        setIsLoggingIn(false);
    }, 3000);

    const [showPassword, setShowPassword] = useState(false);
    const toggleShowPassword = () => {
        setShowPassword(prevState => !prevState);
    }

    const handleLogin = () => {
        setIsLoggingIn(true);
        debouncedLogin();
    }

    return (
        <div className="login-div">
            <h2>Log in</h2>
            <form className="login-form">
                <label>
                    Username:
                    <input type="text" placeholder="Enter a valid username" onChange={(e) => (usernameRef.current = e.target.value)} className="input-email" />
                </label>
                <label>
                    Password: 
                    <input type={showPassword ? "text" : "password"} onChange={(e) => (passwordRef.current = e.target.value)} className="input-password" />
                    <button type="button" onClick={toggleShowPassword} className="btn-password-options">{showPassword ? 'Hide password' : "Show password"}</button>
                </label>
                <button onClick={handleLogin} disabled={isLoggingIn} type="submit">{isLoggingIn ? 'Logging in...' : 'Log in'}</button>
            </form>
        </div>
    )
}

export default LoginForm;