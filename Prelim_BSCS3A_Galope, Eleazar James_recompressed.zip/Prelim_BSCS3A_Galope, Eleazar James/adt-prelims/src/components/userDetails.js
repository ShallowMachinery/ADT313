function UserInformation({ onLogout, userInfo }) {

    const handleLogoutClick = () => {
        if (window.confirm('Are you sure you want to log out?')) {
            onLogout();
        }
    };

    return (
        <div className="user-information-div">
            <div className="user-information">
                <p><strong>First name:</strong> {userInfo.firstname}</p>
                <p><strong>Middle name:</strong> {userInfo.middlename}</p>
                <p><strong>Last name:</strong> {userInfo.lastname}</p>
                <p><strong>Section:</strong> {userInfo.section}</p>
                <button onClick={handleLogoutClick} type="submit">Log out</button>
            </div>

        </div>
    )
}

export default UserInformation;