function StudentInformation() {
    return (
        <div className="student-information">
            <p>Eleazar James S. Galope</p>
            <p>CS-3A</p>
        </div>
    )
}

export default StudentInformation;