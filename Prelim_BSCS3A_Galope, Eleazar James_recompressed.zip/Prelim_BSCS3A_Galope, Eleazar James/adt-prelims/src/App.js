import StudentInformation from './components/nameOnTop';
import LoginForm from './components/loginForm';
import Calculator from './components/calculator';
import UserInformation from './components/userDetails';
import React, { useState, useRef, useCallback } from 'react';
import './App.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const handleLogin = useCallback(() => {
    setIsLoggedIn(true);
  }, []);

  const handleLogout = useCallback(() => {
    setIsLoggedIn(false);
  }, []);

  const userInfo = useRef({ 
      firstname: 'Eleazar James',
      middlename: 'Suriao',
      lastname: 'Galope',
      section: 'BSCS-3A',
      username: 'user',
      password: 'Password123@'
  });

  return (
    <div className="App">
      <StudentInformation />
      <div className="main-content">
        {isLoggedIn ? <UserInformation onLogout={handleLogout} userInfo={userInfo.current} /> : <LoginForm onLogin={handleLogin} userInfo={userInfo.current} />}
      </div>
      <Calculator />
    </div>
  );
}

export default App;
