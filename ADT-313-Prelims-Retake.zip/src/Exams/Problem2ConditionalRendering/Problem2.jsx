import { useState, useEffect } from "react";

function Problem2() {
  const user = {
    name: 'Hedy Lamarr',
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

  const [showProfile, setShowProfile] = useState(false);

  const handleShowProfile = () => {
    if (showProfile) {
      setShowProfile(false);
    } else {
      setShowProfile(true);
    }
  }; 

  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        <img
          className='avatar'
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  function InitialContent() {
    return <h1>User profile is {showProfile ? 'shown.' : "hidden."}</h1>;
  }

  return (
    <>
      <div>
        <InitialContent />
        <button type='button' onClick={handleShowProfile}>{!showProfile ? 'Show' : 'Hide'} Profile</button>
        {showProfile ? <Profile /> : ''}
      </div>
    </>
  );
}

export default Problem2;
