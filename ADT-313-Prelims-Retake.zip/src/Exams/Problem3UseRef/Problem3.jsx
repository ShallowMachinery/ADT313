import { useRef, useState } from "react";

function Problem3() {
  const [input1, setInput1] = useState('');
  const [input2, setInput2] = useState('');
  const [input3, setInput3] = useState('');
  const [input4, setInput4] = useState('');
  const [input5, setInput5] = useState('');
  const [input6, setInput6] = useState('');
  const [input7, setInput7] = useState('');
  const [input8, setInput8] = useState('');
  const [input9, setInput9] = useState('');
  const [input10, setInput10] = useState('');
  const input1Ref = useRef(null);
  const input2Ref = useRef(null);
  const input3Ref = useRef(null);
  const input4Ref = useRef(null);
  const input5Ref = useRef(null);
  const input6Ref = useRef(null);
  const input7Ref = useRef(null);
  const input8Ref = useRef(null);
  const input9Ref = useRef(null);
  const input10Ref = useRef(null);
  
  const handleSetFocus = () => {
    if (input10 === '') {
      input10Ref.current.focus();
    }
    if (input9 === '') {
      input9Ref.current.focus();
    }
    if (input8 === '') {
      input8Ref.current.focus();
    }
    if (input7 === '') {
      input7Ref.current.focus();
    }
    if (input6 === '') {
      input6Ref.current.focus();
    }
    if (input5 === '') {
      input5Ref.current.focus();
    }
    if (input4 === '') {
      input4Ref.current.focus();
    }
    if (input3 === '') {
      input3Ref.current.focus();
    }
    if (input2 === '') {
      input2Ref.current.focus();
    }
    if (input1 === '') {
      input1Ref.current.focus();
    }
  }

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type='text' ref={input1Ref} value={input1} onChange={(e) => setInput1(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type='text' ref={input2Ref} value={input2} onChange={(e) => setInput2(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type='text' ref={input3Ref} value={input3} onChange={(e) => setInput3(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type='text' ref={input4Ref} value={input4} onChange={(e) => setInput4(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type='text' ref={input5Ref} value={input5} onChange={(e) => setInput5(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type='text' ref={input6Ref} value={input6} onChange={(e) => setInput6(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type='text' ref={input7Ref} value={input7} onChange={(e) => setInput7(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type='text' ref={input8Ref} value={input8} onChange={(e) => setInput8(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type='text' ref={input9Ref} value={input9} onChange={(e) => setInput9(e.target.value) }/>
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type='text' ref={input10Ref} value={input10} onChange={(e) => setInput10(e.target.value) }/>
      </div>
      <button type='button' onClick={handleSetFocus}>I'm a button</button>
    </>
  );
}

export default Problem3;
