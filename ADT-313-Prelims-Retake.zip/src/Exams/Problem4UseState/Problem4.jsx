import { useState } from "react";

export default function Problem4() {
  const [userDetails, setUserDetails] = useState({userName: null, userYear: null, userCourse: null})
  const [showDetails, setShowDetails] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserDetails(prevState => ({
        ...prevState,
        [name]: value
    }));
  }

  const handleShowDetails = () => {
    if (showDetails) {
      setShowDetails(false);
    } else {
      setShowDetails(true);
    }
  }
  
  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' value={userDetails.userName} onChange={handleChange} name="userName"/>
      </div>
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input type='radio' id='firstYear' name='yearlevel' value='First Year' checked={userDetails.userYear = "First Year"}/>
          <label for='firstYear'>Fist Year</label>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year' checked={userDetails.userYear = "Second Year"}
        />
          <label for='secondYear'>Second Year</label>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year' checked={userDetails.userYear = "Third Year"}
        />
          <label for='thirdYear'>Third Year</label>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year' checked={userDetails.userYear = "Fourth Year"}
        />
          <label for='fourthYear'>Fourth Year </label>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fourth Year' checked={userDetails.userYear = "Fifth Year"}
        />
          <label for='fifthYear'>Fifth Year</label>
        <br></br>
        <input type='radio' id='irregular' name='yearlevel' value='Irregular' checked={userDetails.userYear = "Irregular"} />
          <label for='irregular'>Irregular</label>
        <br></br>
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select >
          <option value='BSCS' selected={userDetails.userCourse = "BSCS"}>BSCS</option>
          <option value='BSIT' selected={userDetails.userCourse = "BSIT"}>BSIT</option>
          <option value='BSCpE' selected={userDetails.userCourse = "BSCpE"}>BSCpE</option>
          <option value='ACT' selected={userDetails.userCourse = "ACT"}>ACT</option>
        </select>
      </div>
      <button type="button" onClick={handleShowDetails}>Show object</button>
      {showDetails && (<p>{userDetails.userName}, {userDetails.userYear}</p>)}
    </>
  );
}
