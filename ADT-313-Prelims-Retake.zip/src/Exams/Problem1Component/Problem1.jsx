import React, { useState, useEffect } from "react";

function Problem1() {
    const [name, setName] = useState();
    const [course, setCourse] = useState();
    const [section, setSection] = useState();
    
    const user = {
        name: null,
        course: null,
        section: null
    };

    const getDetails = () => {
        user.name = name;
        user.course = course;
        user.section = section;
        console.log(user.name, user.course, user.section);
    }

    return (
        <>
            <form>
                <label>Student name:
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </label><br/>
                <label>Course:
                    <input type="text" value={course} onChange={(e) => setCourse(e.target.value)} />
                </label><br/>
                <label>Section:
                    <input type="text" value={section} onChange={(e) => setSection(e.target.value)} />
                </label><br/>
                <button onClick={getDetails} type="button">Get student details</button>
            </form>
        </>);
}

export default Problem1;